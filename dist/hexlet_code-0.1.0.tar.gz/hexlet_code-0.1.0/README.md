### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ker0s1n/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ker0s1n/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/abe51cbaacce81afb970/maintainability)](https://codeclimate.com/github/Ker0s1n/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/FkyQcaUkUbrYl51R483wYTBlL.svg)](https://asciinema.org/a/FkyQcaUkUbrYl51R483wYTBlL)
[![asciicast](https://asciinema.org/a/rZ2d8TU57xA4Hg5jt0OFooY2s.svg)](https://asciinema.org/a/rZ2d8TU57xA4Hg5jt0OFooY2s)
[![asciicast](https://asciinema.org/a/wNO4rG4KwnuGcLR1vX2W455jK.svg)](https://asciinema.org/a/wNO4rG4KwnuGcLR1vX2W455jK)
[![asciicast](https://asciinema.org/a/5jZvRfHW956ks7xrWIyRSG5y1.svg)](https://asciinema.org/a/5jZvRfHW956ks7xrWIyRSG5y1)
